package odeen.weatherpredictor;

import android.app.IntentService;
import android.content.Intent;

/**
 * Created by Женя on 24.11.2014.
 */
public class WeatherService extends IntentService {
    private static final String TAG = "WeatherService";

    public static final String EXTRA_CITY = "city";

    public WeatherService() {
        super("WeatherService");
    }

    private String getCurrentWeatherURL(String city) {
        return "http://api.openweathermap.org/data/2.5/weather?q=" + city + "&mode=xml";
    }

    @Override
    protected void onHandleIntent(Intent intent) {
        String city = intent.getStringExtra(EXTRA_CITY);


    }




}
