package odeen.weatherpredictor;


import java.util.Date;

/**
 * Created by Женя on 23.11.2014.
 */
public class Weather {

    private Temperature mTemperature;
    private Wind mWind;
    private Humidity mHumidity;
    private Pressure mPressure;
    private Clouds mClouds;
    private WeatherInfo mInfo;

    Weather(WeatherInfo info, Temperature temperature, Wind wind, Humidity humidity,
            Pressure pressure, Clouds clouds) {
        mTemperature = temperature;
        mHumidity = humidity;
        mWind = wind;
        mClouds = clouds;
        mInfo = info;
        mPressure = pressure;
    }

    public Temperature getTemperature() {
        return mTemperature;
    }

    public void setTemperature(Temperature temperature) {
        this.mTemperature = temperature;
    }

    public Wind getWind() {
        return mWind;
    }

    public void setWind(Wind wind) {
        this.mWind = wind;
    }

    public Humidity getHumidity() {
        return mHumidity;
    }

    public void setHumidity(Humidity humidity) {
        this.mHumidity = humidity;
    }

    public Pressure getPressure() {
        return mPressure;
    }

    public void setPressure(Pressure pressure) {
        this.mPressure = pressure;
    }

    public Clouds getClouds() {
        return mClouds;
    }

    public void setClouds(Clouds clouds) {
        this.mClouds = clouds;
    }

    public WeatherInfo getInfo() {
        return mInfo;
    }

    public void setInfo(WeatherInfo mInfo) {
        this.mInfo = mInfo;
    }

    public static class WeatherInfo {
        private Date mLastUpdate;
        private int mNumber;
        private String mName;
        private String mIconId;

        public WeatherInfo(Date mLastUpdate, int mNumber, String mName, String mIconId) {
            this.mLastUpdate = mLastUpdate;
            this.mNumber = mNumber;
            this.mName = mName;
            this.mIconId = mIconId;
        }

        public String getIconId() {
            return mIconId;
        }

        public void setIconId(String mIconId) {
            this.mIconId = mIconId;
        }

        public String getName() {
            return mName;
        }

        public void setName(String mName) {
            this.mName = mName;
        }

        public int getNumber() {
            return mNumber;
        }

        public void setNumber(int mNumber) {
            this.mNumber = mNumber;
        }

        public Date getLastUpdate() {
            return mLastUpdate;
        }

        public void setLastUpdate(Date mLastUpdate) {
            this.mLastUpdate = mLastUpdate;
        }
    }

    public static class Temperature {
        private Double mValue;
        private Double mMinValue;
        private Double mMaxValue;

        Temperature(double value, double min, double max) {
            this.mValue = value;
            this.mMinValue = min;
            this.mMaxValue = max;
        }
        public double getMaxValue() {
            return mMaxValue;
        }
        public double getMinValue() {
            return mMinValue;
        }
        public double getValue() {
            return mValue;
        }
    }

    public static class Wind {
        private final double mSpeedValue;
        private final String mSpeedName;
        private final double mDirectionValue;
        private final String mDirectionCode;
        private final String mDirectionName;

        Wind(double speed, String speedName, double dirValue, String dirCode, String dirName) {
            mSpeedValue = speed;
            mSpeedName = speedName;
            mDirectionValue = dirValue;
            mDirectionCode = dirCode;
            mDirectionName = dirName;
        }

        public double getSpeedValue() {
            return mSpeedValue;
        }

        public String getSpeedName() {
            return mSpeedName;
        }

        public double getDirectionValue() {
            return mDirectionValue;
        }

        public String getDirectionCode() {
            return mDirectionCode;
        }

        public String getDirectionName() {
            return mDirectionName;
        }
    }

    public static class Humidity {
        private final double mValue;
        private final String mUnit;
        Humidity(double hum, String unit) {
            mValue = hum;
            mUnit = unit;
        }

        public double getValue() {
            return mValue;
        }
    }

    public static class Pressure {
        private final double mValue;
        private final String mUnit;
        Pressure(double pres, String unit) {
            mValue = pres;
            mUnit = unit;
        }

        public double getValue() {
            return mValue;
        }
    }

    public static class Clouds {
        private final double mValue;
        private final String mName;
        Clouds(double val, String name) {
            mValue = val;
            mName = name;
        }

        public double getValue() {
            return mValue;
        }

        public String getName() {
            return mName;
        }
    }

}



