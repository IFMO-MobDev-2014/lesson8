package odeen.weatherpredictor;

/**
 * Created by Женя on 24.11.2014.
 */
public class WeatherManager {
}
