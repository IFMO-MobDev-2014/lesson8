package odeen.weatherpredictor;

import android.renderscript.Element;

import org.json.JSONObject;
import org.w3c.dom.Document;
import org.w3c.dom.Node;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by Женя on 24.11.2014.
 */

public class CurrentWeather extends Weather {

    static private SimpleDateFormat sFormat = new SimpleDateFormat("yyyy-mm-ddThh:mm:ss");

    CurrentWeather(WeatherInfo info, Temperature temperature, Wind wind, Humidity humidity,
                   Pressure pressure, Clouds clouds) {
        super(info, temperature, wind, humidity, pressure, clouds);
    }

    CurrentWeather(Document object) {
        super(parseWeatherInfo(object), parseTemperature(object), parseWind(object),
                parseHumidity(object), parsePressure(object), parseClouds(object));
    }


    private static String getStringValue(Node el, String atr) {
        return el.getAttributes().getNamedItem(atr).getNodeValue();
    }

    private static double getDoubleValue(Node el, String atr) {
        return Double.parseDouble(el.getAttributes().getNamedItem(atr).getNodeValue());
    }
    private static int getIntValue(Node el, String atr) {
        return Integer.parseInt(el.getAttributes().getNamedItem(atr).getNodeValue());
    }


    private static WeatherInfo parseWeatherInfo(Document doc) {
        try {
            Date lastUpdate = sFormat.parse(getStringValue(doc.getElementsByTagName("lastupdate").item(0), "value"));
            int number = getIntValue(doc.getElementsByTagName("weather").item(0), "number");
            String iconId = getStringValue(doc.getElementsByTagName("weather").item(0), "icon");
            String name = getStringValue(doc.getElementsByTagName("weather").item(0), "value");
            return new WeatherInfo(lastUpdate, number, name, iconId);
        } catch (Exception e) {
            return null;
        }
    }

    private static Temperature parseTemperature(Document doc) {
        try {
            Node t = doc.getElementsByTagName("temperature").item(0);
            double value = getDoubleValue(t, "value");
            double min = getDoubleValue(t, "min");
            double max = getDoubleValue(t, "max");
            String unit = getStringValue(t, "unit");
            if (unit.equals("kelvin")) {
                value -= 273.15;
                min -= 273.15;
                max -= 273.15;
            }
            return new Temperature(value, min, max);
        } catch (Exception e) {
            return null;
        }
    }

    private static Wind parseWind(Document doc) {
        try {
            Node speedDoc = doc.getElementsByTagName("wind").item(0).getFirstChild();
            double speedValue = getDoubleValue(speedDoc, "value");
            String speedName = getStringValue(speedDoc, "name");

            Node dirDoc = doc.getElementsByTagName("wind").item(0).getLastChild();
            double directionValue = getDoubleValue(dirDoc, "value");
            String directionCode = getStringValue(dirDoc, "code");
            String directionName = getStringValue(dirDoc, "name");
            return new Wind(speedValue, speedName, directionValue, directionCode, directionName);
        } catch (Exception e) {
            return null;
        }
    }

    private static Humidity parseHumidity(Document doc) {
        try {
            Node t = doc.getElementsByTagName("humidity").item(0);
            double value= getDoubleValue(t, "value");
            String unit = getStringValue(t, "unit");
            return new Humidity(value, unit);
        } catch (Exception e) {
            return null;
        }
    }

    private static Pressure parsePressure(Document doc) {
        try {
            Node t = doc.getElementsByTagName("pressure").item(0);
            double value= getDoubleValue(t, "value");
            String unit = getStringValue(t, "unit");
            return new Pressure(value, unit);
        } catch (Exception e) {
            return null;
        }
    }

    private static Clouds parseClouds(Document doc) {
        try {
            Node t = doc.getElementsByTagName("clouds").item(0);
            double value= getDoubleValue(t, "value");
            String name = getStringValue(t, "name");
            return new Clouds(value, name);
        } catch (Exception e) {
            return null;
        }
    }

}
