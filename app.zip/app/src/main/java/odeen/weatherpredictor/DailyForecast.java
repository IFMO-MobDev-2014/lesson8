package odeen.weatherpredictor;

import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Document;
import org.w3c.dom.Node;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

/**
 * Created by Женя on 23.11.2014.
 */

public class DailyForecast {
    private Day mDay;
    private ArrayList<TimedWeather> weathers;

    DailyForecast(Date day) {
        weathers = new ArrayList<TimedWeather>();
        mDay = new Day(day);
    }

    boolean addPart(TimedWeather t) {
        if (!new Day(t.getFrom()).equals(mDay))
            return false;
        weathers.add(t);
        return true;
    }

    public Day getDay() {
        return mDay;
    }

    public void setDay(Day mDay) {
        this.mDay = mDay;
    }


    public static class Day {
        private int mYear;
        private int mMonth;
        private int mDay;
        Day(Date date) {
            Calendar c = GregorianCalendar.getInstance();
            c.setTime(date);
            mYear = c.get(Calendar.YEAR);
            mMonth = c.get(Calendar.MONTH);
            mDay = c.get(Calendar.DAY_OF_MONTH);
        }

        @Override
        public boolean equals(Object other) {
            Day t = (Day)other;
            return t.getYear() == getYear() && t.getMonth() == getMonth() && t.getDay() == getDay();
        }

        public int getYear() {
            return mYear;
        }

        public void setYear(int mYear) {
            this.mYear = mYear;
        }

        public int getMonth() {
            return mMonth;
        }

        public void setMonth(int mMonth) {
            this.mMonth = mMonth;
        }

        public int getDay() {
            return mDay;
        }

        public void setDay(int mDay) {
            this.mDay = mDay;
        }
    }

    public static class TimedWeather extends Weather {
        static private SimpleDateFormat sFormat = new SimpleDateFormat("yyyy-mm-ddThh:mm:ss");

        private Date mFrom;
        private Date mTo;

        TimedWeather(WeatherInfo info, Temperature temperature, Wind wind,
                     Humidity humidity, Pressure pressure, Clouds clouds, Date from, Date to) {
            super(info, temperature, wind, humidity, pressure, clouds);
            mFrom = from;
            mTo = to;
        }

        TimedWeather(Document object) {
            super(parseWeatherInfo(object), parseTemperature(object), parseWind(object),
                    parseHumidity(object), parsePressure(object), parseClouds(object));
            try {
                mFrom = sFormat.parse(getStringValue(object, "from"));
            } catch (Exception e) {
                e.printStackTrace();
            }
            try {
                mTo = sFormat.parse(getStringValue(object, "to"));
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        private static WeatherInfo parseWeatherInfo(Document doc) {
            try {
                int number = getIntValue(doc.getElementsByTagName("symbol").item(0), "number");
                String iconId = getStringValue(doc.getElementsByTagName("symbol").item(0), "war");
                String name = getStringValue(doc.getElementsByTagName("symbol").item(0), "name");
                return new WeatherInfo(null, number, name, iconId);
            } catch (Exception e) {
                return null;
            }
        }

        private static Temperature parseTemperature(Document doc) {
            try {
                Node t = doc.getElementsByTagName("temperature").item(0);
                double value = getDoubleValue(t, "value");
                double min = getDoubleValue(t, "min");
                double max = getDoubleValue(t, "max");
                String unit = getStringValue(t, "unit");
                if (unit.equals("kelvin")) {
                    value -= 273.15;
                    min -= 273.15;
                    max -= 273.15;
                }
                return new Temperature(value, min, max);
            } catch (Exception e) {
                return null;
            }
        }

        private static Wind parseWind(Document doc) {
            try {
                Node speedDoc = doc.getElementsByTagName("windSpeed").item(0);
                double speedValue = getDoubleValue(speedDoc, "mps");
                String speedName = getStringValue(speedDoc, "name");

                Node dirDoc = doc.getElementsByTagName("windDirection").item(0).getLastChild();
                double directionValue = getDoubleValue(dirDoc, "deg");
                String directionCode = getStringValue(dirDoc, "code");
                String directionName = getStringValue(dirDoc, "name");
                return new Wind(speedValue, speedName, directionValue, directionCode, directionName);
            } catch (Exception e) {
                return null;
            }
        }

        private static Humidity parseHumidity(Document doc) {
            try {
                Node t = doc.getElementsByTagName("humidity").item(0);
                double value= getDoubleValue(t, "value");
                String unit = getStringValue(t, "unit");
                return new Humidity(value, unit);
            } catch (Exception e) {
                return null;
            }
        }

        private static Pressure parsePressure(Document doc) {
            try {
                Node t = doc.getElementsByTagName("pressure").item(0);
                double value= getDoubleValue(t, "value");
                String unit = getStringValue(t, "unit");
                return new Pressure(value, unit);
            } catch (Exception e) {
                return null;
            }
        }

        private static Clouds parseClouds(Document doc) {
            try {
                Node t = doc.getElementsByTagName("clouds").item(0);
                double value= getDoubleValue(t, "all");
                String name = getStringValue(t, "value");
                return new Clouds(value, name);
            } catch (Exception e) {
                return null;
            }
        }


        public Date getTo() {
            return mTo;
        }

        public void setTo(Date mTo) {
            this.mTo = mTo;
        }

        public Date getFrom() {
            return mFrom;
        }

        public void setFrom(Date mFrom) {
            this.mFrom = mFrom;
        }
    }


    private static String getStringValue(Node el, String atr) {
        return el.getAttributes().getNamedItem(atr).getNodeValue();
    }

    private static double getDoubleValue(Node el, String atr) {
        return Double.parseDouble(el.getAttributes().getNamedItem(atr).getNodeValue());
    }
    private static int getIntValue(Node el, String atr) {
        return Integer.parseInt(el.getAttributes().getNamedItem(atr).getNodeValue());
    }
}
